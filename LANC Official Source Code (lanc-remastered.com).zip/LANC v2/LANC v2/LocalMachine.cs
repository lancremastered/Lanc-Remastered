using System;
using System.Runtime.CompilerServices;

namespace LANC_v2
{
	internal class LocalMachine
	{
		public string IP
		{
			get;
			set;
		}

		public string macAddress
		{
			get;
			set;
		}

		public string macVendor
		{
			get;
			set;
		}

		public string Name
		{
			get;
			set;
		}

		public LocalMachine()
		{
		}
	}
}