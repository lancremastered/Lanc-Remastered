﻿namespace LANC_v2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.logInTabControl1 = new LoginTheme.LogInTabControl();
            this.HomeTab = new System.Windows.Forms.TabPage();
            this.logInLabel9 = new LoginTheme.LogInLabel();
            this.logInLabel8 = new LoginTheme.LogInLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.logInGroupBox2 = new LoginTheme.LogInGroupBox();
            this.logInComboBox3 = new LoginTheme.LogInComboBox();
            this.logInLabel2 = new LoginTheme.LogInLabel();
            this.logInComboBox2 = new LoginTheme.LogInComboBox();
            this.logInLabel1 = new LoginTheme.LogInLabel();
            this.logInGroupBox1 = new LoginTheme.LogInGroupBox();
            this.logInNormalTextBox4 = new LoginTheme.LogInNormalTextBox();
            this.logInLabel6 = new LoginTheme.LogInLabel();
            this.logInNormalTextBox3 = new LoginTheme.LogInNormalTextBox();
            this.logInLabel5 = new LoginTheme.LogInLabel();
            this.logInNormalTextBox2 = new LoginTheme.LogInNormalTextBox();
            this.logInLabel4 = new LoginTheme.LogInLabel();
            this.logInNormalTextBox1 = new LoginTheme.LogInNormalTextBox();
            this.logInLabel3 = new LoginTheme.LogInLabel();
            this.logInComboBox1 = new LoginTheme.LogInComboBox();
            this.logInCheckBox2 = new LoginTheme.LogInCheckBox();
            this.logInCheckBox1 = new LoginTheme.LogInCheckBox();
            this.logInButton1 = new LoginTheme.LogInButton();
            this.ConnectionsTab = new System.Windows.Forms.TabPage();
            this.logInButton2 = new LoginTheme.LogInButton();
            this.logInCheckBox3 = new LoginTheme.LogInCheckBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.logInContextMenu2 = new LoginTheme.LogInContextMenu();
            this.addLabelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.copyLabelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyGeolocationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyIPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyPacketsNumberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copySourceIPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copySourcePortToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyDestinationIPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyDestinationPortToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyMACToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyProtocolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyHWDVendorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LANMTab = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.DBTab = new System.Windows.Forms.TabPage();
            this.listView1 = new System.Windows.Forms.ListView();
            this.Label = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.IPC = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.logInContextMenu1 = new LoginTheme.LogInContextMenu();
            this.refreshDBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DebugTab = new System.Windows.Forms.TabPage();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.logInThemeContainer1 = new LoginTheme.LogInThemeContainer();
            this.logInTabControl1.SuspendLayout();
            this.HomeTab.SuspendLayout();
            this.panel1.SuspendLayout();
            this.logInGroupBox2.SuspendLayout();
            this.logInGroupBox1.SuspendLayout();
            this.ConnectionsTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.logInContextMenu2.SuspendLayout();
            this.LANMTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.DBTab.SuspendLayout();
            this.logInContextMenu1.SuspendLayout();
            this.DebugTab.SuspendLayout();
            this.logInThemeContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // logInTabControl1
            // 
            this.logInTabControl1.ActiveColour = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(47)))), ((int)(((byte)(47)))));
            this.logInTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.logInTabControl1.BackTabColour = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.logInTabControl1.BaseColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInTabControl1.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.logInTabControl1.Controls.Add(this.HomeTab);
            this.logInTabControl1.Controls.Add(this.ConnectionsTab);
            this.logInTabControl1.Controls.Add(this.LANMTab);
            this.logInTabControl1.Controls.Add(this.DBTab);
            this.logInTabControl1.Controls.Add(this.DebugTab);
            this.logInTabControl1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.logInTabControl1.HorizontalLineColour = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(119)))), ((int)(((byte)(151)))));
            this.logInTabControl1.ItemSize = new System.Drawing.Size(240, 32);
            this.logInTabControl1.Location = new System.Drawing.Point(0, 35);
            this.logInTabControl1.Multiline = true;
            this.logInTabControl1.Name = "logInTabControl1";
            this.logInTabControl1.SelectedIndex = 0;
            this.logInTabControl1.Size = new System.Drawing.Size(813, 290);
            this.logInTabControl1.TabIndex = 0;
            this.logInTabControl1.TextColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInTabControl1.UpLineColour = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(160)))), ((int)(((byte)(199)))));
            // 
            // HomeTab
            // 
            this.HomeTab.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.HomeTab.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.HomeTab.Controls.Add(this.logInLabel9);
            this.HomeTab.Controls.Add(this.logInLabel8);
            this.HomeTab.Controls.Add(this.panel1);
            this.HomeTab.Controls.Add(this.logInComboBox1);
            this.HomeTab.Controls.Add(this.logInCheckBox2);
            this.HomeTab.Controls.Add(this.logInCheckBox1);
            this.HomeTab.Controls.Add(this.logInButton1);
            this.HomeTab.ImageIndex = 3;
            this.HomeTab.Location = new System.Drawing.Point(4, 36);
            this.HomeTab.Name = "HomeTab";
            this.HomeTab.Padding = new System.Windows.Forms.Padding(3);
            this.HomeTab.Size = new System.Drawing.Size(805, 250);
            this.HomeTab.TabIndex = 0;
            this.HomeTab.Text = "Home";
            // 
            // logInLabel9
            // 
            this.logInLabel9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.logInLabel9.AutoSize = true;
            this.logInLabel9.BackColor = System.Drawing.Color.Transparent;
            this.logInLabel9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.logInLabel9.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel9.Location = new System.Drawing.Point(0, 233);
            this.logInLabel9.Name = "logInLabel9";
            this.logInLabel9.Size = new System.Drawing.Size(0, 15);
            this.logInLabel9.TabIndex = 6;
            // 
            // logInLabel8
            // 
            this.logInLabel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.logInLabel8.AutoSize = true;
            this.logInLabel8.BackColor = System.Drawing.Color.Transparent;
            this.logInLabel8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.logInLabel8.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel8.Location = new System.Drawing.Point(0, 215);
            this.logInLabel8.Name = "logInLabel8";
            this.logInLabel8.Size = new System.Drawing.Size(0, 15);
            this.logInLabel8.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.logInGroupBox2);
            this.panel1.Controls.Add(this.logInGroupBox1);
            this.panel1.Location = new System.Drawing.Point(-1, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(805, 168);
            this.panel1.TabIndex = 4;
            // 
            // logInGroupBox2
            // 
            this.logInGroupBox2.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInGroupBox2.Controls.Add(this.logInComboBox3);
            this.logInGroupBox2.Controls.Add(this.logInLabel2);
            this.logInGroupBox2.Controls.Add(this.logInComboBox2);
            this.logInGroupBox2.Controls.Add(this.logInLabel1);
            this.logInGroupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.logInGroupBox2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.logInGroupBox2.HeaderColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInGroupBox2.Location = new System.Drawing.Point(0, 98);
            this.logInGroupBox2.MainColour = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(47)))), ((int)(((byte)(47)))));
            this.logInGroupBox2.Name = "logInGroupBox2";
            this.logInGroupBox2.Size = new System.Drawing.Size(803, 63);
            this.logInGroupBox2.TabIndex = 1;
            this.logInGroupBox2.Text = "ARP Spoofing";
            this.logInGroupBox2.TextColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInGroupBox2.Visible = false;
            // 
            // logInComboBox3
            // 
            this.logInComboBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logInComboBox3.ArrowColour = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.logInComboBox3.BackColor = System.Drawing.Color.Transparent;
            this.logInComboBox3.BaseColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInComboBox3.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInComboBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.logInComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.logInComboBox3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.logInComboBox3.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInComboBox3.FormattingEnabled = true;
            this.logInComboBox3.LineColour = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(119)))), ((int)(((byte)(151)))));
            this.logInComboBox3.Location = new System.Drawing.Point(573, 32);
            this.logInComboBox3.Name = "logInComboBox3";
            this.logInComboBox3.Size = new System.Drawing.Size(190, 26);
            this.logInComboBox3.SqaureColour = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(47)))), ((int)(((byte)(47)))));
            this.logInComboBox3.SqaureHoverColour = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.logInComboBox3.StartIndex = 0;
            this.logInComboBox3.TabIndex = 2;
            // 
            // logInLabel2
            // 
            this.logInLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logInLabel2.AutoSize = true;
            this.logInLabel2.BackColor = System.Drawing.Color.Transparent;
            this.logInLabel2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.logInLabel2.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel2.Location = new System.Drawing.Point(551, 36);
            this.logInLabel2.Name = "logInLabel2";
            this.logInLabel2.Size = new System.Drawing.Size(24, 15);
            this.logInLabel2.TabIndex = 3;
            this.logInLabel2.Text = "To:";
            // 
            // logInComboBox2
            // 
            this.logInComboBox2.ArrowColour = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.logInComboBox2.BackColor = System.Drawing.Color.Transparent;
            this.logInComboBox2.BaseColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInComboBox2.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.logInComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.logInComboBox2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.logInComboBox2.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInComboBox2.FormattingEnabled = true;
            this.logInComboBox2.LineColour = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(119)))), ((int)(((byte)(151)))));
            this.logInComboBox2.Location = new System.Drawing.Point(72, 32);
            this.logInComboBox2.Name = "logInComboBox2";
            this.logInComboBox2.Size = new System.Drawing.Size(190, 26);
            this.logInComboBox2.SqaureColour = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(47)))), ((int)(((byte)(47)))));
            this.logInComboBox2.SqaureHoverColour = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.logInComboBox2.StartIndex = 0;
            this.logInComboBox2.TabIndex = 0;
            // 
            // logInLabel1
            // 
            this.logInLabel1.AutoSize = true;
            this.logInLabel1.BackColor = System.Drawing.Color.Transparent;
            this.logInLabel1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.logInLabel1.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel1.Location = new System.Drawing.Point(36, 36);
            this.logInLabel1.Name = "logInLabel1";
            this.logInLabel1.Size = new System.Drawing.Size(38, 15);
            this.logInLabel1.TabIndex = 1;
            this.logInLabel1.Text = "From:";
            // 
            // logInGroupBox1
            // 
            this.logInGroupBox1.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInGroupBox1.Controls.Add(this.logInNormalTextBox4);
            this.logInGroupBox1.Controls.Add(this.logInLabel6);
            this.logInGroupBox1.Controls.Add(this.logInNormalTextBox3);
            this.logInGroupBox1.Controls.Add(this.logInLabel5);
            this.logInGroupBox1.Controls.Add(this.logInNormalTextBox2);
            this.logInGroupBox1.Controls.Add(this.logInLabel4);
            this.logInGroupBox1.Controls.Add(this.logInNormalTextBox1);
            this.logInGroupBox1.Controls.Add(this.logInLabel3);
            this.logInGroupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.logInGroupBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.logInGroupBox1.HeaderColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.logInGroupBox1.MainColour = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(47)))), ((int)(((byte)(47)))));
            this.logInGroupBox1.Name = "logInGroupBox1";
            this.logInGroupBox1.Size = new System.Drawing.Size(803, 98);
            this.logInGroupBox1.TabIndex = 0;
            this.logInGroupBox1.Text = "Filter";
            this.logInGroupBox1.TextColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInGroupBox1.Visible = false;
            // 
            // logInNormalTextBox4
            // 
            this.logInNormalTextBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logInNormalTextBox4.BackColor = System.Drawing.Color.Transparent;
            this.logInNormalTextBox4.BackgroundColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInNormalTextBox4.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInNormalTextBox4.Location = new System.Drawing.Point(561, 32);
            this.logInNormalTextBox4.MaxLength = 32767;
            this.logInNormalTextBox4.Multiline = false;
            this.logInNormalTextBox4.Name = "logInNormalTextBox4";
            this.logInNormalTextBox4.ReadOnly = false;
            this.logInNormalTextBox4.Size = new System.Drawing.Size(239, 29);
            this.logInNormalTextBox4.Style = LoginTheme.LogInNormalTextBox.Styles.NotRounded;
            this.logInNormalTextBox4.TabIndex = 12;
            this.logInNormalTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.logInNormalTextBox4.TextColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInNormalTextBox4.UseSystemPasswordChar = false;
            // 
            // logInLabel6
            // 
            this.logInLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logInLabel6.AutoSize = true;
            this.logInLabel6.BackColor = System.Drawing.Color.Transparent;
            this.logInLabel6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.logInLabel6.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel6.Location = new System.Drawing.Point(479, 39);
            this.logInLabel6.Name = "logInLabel6";
            this.logInLabel6.Size = new System.Drawing.Size(83, 15);
            this.logInLabel6.TabIndex = 13;
            this.logInLabel6.Text = "Destination IP:";
            // 
            // logInNormalTextBox3
            // 
            this.logInNormalTextBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logInNormalTextBox3.BackColor = System.Drawing.Color.Transparent;
            this.logInNormalTextBox3.BackgroundColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInNormalTextBox3.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInNormalTextBox3.Location = new System.Drawing.Point(573, 63);
            this.logInNormalTextBox3.MaxLength = 32767;
            this.logInNormalTextBox3.Multiline = false;
            this.logInNormalTextBox3.Name = "logInNormalTextBox3";
            this.logInNormalTextBox3.ReadOnly = false;
            this.logInNormalTextBox3.Size = new System.Drawing.Size(227, 29);
            this.logInNormalTextBox3.Style = LoginTheme.LogInNormalTextBox.Styles.NotRounded;
            this.logInNormalTextBox3.TabIndex = 10;
            this.logInNormalTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.logInNormalTextBox3.TextColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInNormalTextBox3.UseSystemPasswordChar = false;
            // 
            // logInLabel5
            // 
            this.logInLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logInLabel5.AutoSize = true;
            this.logInLabel5.BackColor = System.Drawing.Color.Transparent;
            this.logInLabel5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.logInLabel5.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel5.Location = new System.Drawing.Point(479, 70);
            this.logInLabel5.Name = "logInLabel5";
            this.logInLabel5.Size = new System.Drawing.Size(95, 15);
            this.logInLabel5.TabIndex = 11;
            this.logInLabel5.Text = "Destination Port:";
            // 
            // logInNormalTextBox2
            // 
            this.logInNormalTextBox2.BackColor = System.Drawing.Color.Transparent;
            this.logInNormalTextBox2.BackgroundColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInNormalTextBox2.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInNormalTextBox2.Location = new System.Drawing.Point(62, 32);
            this.logInNormalTextBox2.MaxLength = 32767;
            this.logInNormalTextBox2.Multiline = false;
            this.logInNormalTextBox2.Name = "logInNormalTextBox2";
            this.logInNormalTextBox2.ReadOnly = false;
            this.logInNormalTextBox2.Size = new System.Drawing.Size(212, 29);
            this.logInNormalTextBox2.Style = LoginTheme.LogInNormalTextBox.Styles.NotRounded;
            this.logInNormalTextBox2.TabIndex = 8;
            this.logInNormalTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.logInNormalTextBox2.TextColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInNormalTextBox2.UseSystemPasswordChar = false;
            // 
            // logInLabel4
            // 
            this.logInLabel4.AutoSize = true;
            this.logInLabel4.BackColor = System.Drawing.Color.Transparent;
            this.logInLabel4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.logInLabel4.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel4.Location = new System.Drawing.Point(3, 39);
            this.logInLabel4.Name = "logInLabel4";
            this.logInLabel4.Size = new System.Drawing.Size(59, 15);
            this.logInLabel4.TabIndex = 9;
            this.logInLabel4.Text = "Source IP:";
            // 
            // logInNormalTextBox1
            // 
            this.logInNormalTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.logInNormalTextBox1.BackgroundColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInNormalTextBox1.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInNormalTextBox1.Location = new System.Drawing.Point(72, 63);
            this.logInNormalTextBox1.MaxLength = 32767;
            this.logInNormalTextBox1.Multiline = false;
            this.logInNormalTextBox1.Name = "logInNormalTextBox1";
            this.logInNormalTextBox1.ReadOnly = false;
            this.logInNormalTextBox1.Size = new System.Drawing.Size(202, 29);
            this.logInNormalTextBox1.Style = LoginTheme.LogInNormalTextBox.Styles.NotRounded;
            this.logInNormalTextBox1.TabIndex = 0;
            this.logInNormalTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.logInNormalTextBox1.TextColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInNormalTextBox1.UseSystemPasswordChar = false;
            // 
            // logInLabel3
            // 
            this.logInLabel3.AutoSize = true;
            this.logInLabel3.BackColor = System.Drawing.Color.Transparent;
            this.logInLabel3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.logInLabel3.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInLabel3.Location = new System.Drawing.Point(3, 70);
            this.logInLabel3.Name = "logInLabel3";
            this.logInLabel3.Size = new System.Drawing.Size(71, 15);
            this.logInLabel3.TabIndex = 7;
            this.logInLabel3.Text = "Source Port:";
            // 
            // logInComboBox1
            // 
            this.logInComboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.logInComboBox1.ArrowColour = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.logInComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.logInComboBox1.BaseColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInComboBox1.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.logInComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.logInComboBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.logInComboBox1.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInComboBox1.FormattingEnabled = true;
            this.logInComboBox1.LineColour = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(119)))), ((int)(((byte)(151)))));
            this.logInComboBox1.Location = new System.Drawing.Point(2, 1);
            this.logInComboBox1.Name = "logInComboBox1";
            this.logInComboBox1.Size = new System.Drawing.Size(613, 26);
            this.logInComboBox1.SqaureColour = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(47)))), ((int)(((byte)(47)))));
            this.logInComboBox1.SqaureHoverColour = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.logInComboBox1.StartIndex = 0;
            this.logInComboBox1.TabIndex = 3;
            this.logInComboBox1.SelectedIndexChanged += new System.EventHandler(this.logInComboBox1_SelectedIndexChanged);
            // 
            // logInCheckBox2
            // 
            this.logInCheckBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logInCheckBox2.BaseColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInCheckBox2.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInCheckBox2.Checked = false;
            this.logInCheckBox2.CheckedColour = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(173)))), ((int)(((byte)(174)))));
            this.logInCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logInCheckBox2.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInCheckBox2.Location = new System.Drawing.Point(731, 3);
            this.logInCheckBox2.Name = "logInCheckBox2";
            this.logInCheckBox2.Size = new System.Drawing.Size(58, 22);
            this.logInCheckBox2.TabIndex = 2;
            this.logInCheckBox2.Text = "Filter";
            this.logInCheckBox2.CheckedChanged += new LoginTheme.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox2_CheckedChanged);
            // 
            // logInCheckBox1
            // 
            this.logInCheckBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logInCheckBox1.BaseColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInCheckBox1.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInCheckBox1.Checked = false;
            this.logInCheckBox1.CheckedColour = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(173)))), ((int)(((byte)(174)))));
            this.logInCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logInCheckBox1.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInCheckBox1.Location = new System.Drawing.Point(621, 3);
            this.logInCheckBox1.Name = "logInCheckBox1";
            this.logInCheckBox1.Size = new System.Drawing.Size(108, 22);
            this.logInCheckBox1.TabIndex = 1;
            this.logInCheckBox1.Text = "ARP Spoofing";
            this.logInCheckBox1.CheckedChanged += new LoginTheme.LogInCheckBox.CheckedChangedEventHandler(this.logInCheckBox1_CheckedChanged);
            // 
            // logInButton1
            // 
            this.logInButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.logInButton1.BackColor = System.Drawing.Color.Transparent;
            this.logInButton1.BaseColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInButton1.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.logInButton1.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInButton1.HoverColour = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.logInButton1.Location = new System.Drawing.Point(726, 216);
            this.logInButton1.Name = "logInButton1";
            this.logInButton1.PressedColour = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(47)))), ((int)(((byte)(47)))));
            this.logInButton1.ProgressColour = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(191)))), ((int)(((byte)(255)))));
            this.logInButton1.Size = new System.Drawing.Size(75, 30);
            this.logInButton1.TabIndex = 0;
            this.logInButton1.Text = "Start";
            this.logInButton1.Click += new System.EventHandler(this.logInButton1_Click);
            // 
            // ConnectionsTab
            // 
            this.ConnectionsTab.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.ConnectionsTab.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ConnectionsTab.Controls.Add(this.logInButton2);
            this.ConnectionsTab.Controls.Add(this.logInCheckBox3);
            this.ConnectionsTab.Controls.Add(this.dataGridView1);
            this.ConnectionsTab.ImageIndex = 4;
            this.ConnectionsTab.Location = new System.Drawing.Point(4, 36);
            this.ConnectionsTab.Name = "ConnectionsTab";
            this.ConnectionsTab.Size = new System.Drawing.Size(805, 250);
            this.ConnectionsTab.TabIndex = 1;
            this.ConnectionsTab.Text = "Connections";
            // 
            // logInButton2
            // 
            this.logInButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.logInButton2.BackColor = System.Drawing.Color.Transparent;
            this.logInButton2.BaseColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInButton2.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.logInButton2.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInButton2.HoverColour = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            this.logInButton2.Location = new System.Drawing.Point(726, 220);
            this.logInButton2.Name = "logInButton2";
            this.logInButton2.PressedColour = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(47)))), ((int)(((byte)(47)))));
            this.logInButton2.ProgressColour = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(191)))), ((int)(((byte)(255)))));
            this.logInButton2.Size = new System.Drawing.Size(75, 27);
            this.logInButton2.TabIndex = 2;
            this.logInButton2.Text = "Start";
            this.logInButton2.Click += new System.EventHandler(this.logInButton2_Click);
            // 
            // logInCheckBox3
            // 
            this.logInCheckBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.logInCheckBox3.BaseColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInCheckBox3.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInCheckBox3.Checked = false;
            this.logInCheckBox3.CheckedColour = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(173)))), ((int)(((byte)(174)))));
            this.logInCheckBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logInCheckBox3.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInCheckBox3.Location = new System.Drawing.Point(1, 225);
            this.logInCheckBox3.Name = "logInCheckBox3";
            this.logInCheckBox3.Size = new System.Drawing.Size(238, 22);
            this.logInCheckBox3.TabIndex = 1;
            this.logInCheckBox3.Text = "Dynamically Remove Inactive Entries";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.logInContextMenu2;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.ShowEditingIcon = false;
            this.dataGridView1.ShowRowErrors = false;
            this.dataGridView1.Size = new System.Drawing.Size(803, 219);
            this.dataGridView1.TabIndex = 0;
            // 
            // logInContextMenu2
            // 
            this.logInContextMenu2.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInContextMenu2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInContextMenu2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addLabelToolStripMenuItem,
            this.toolStripSeparator1,
            this.copyLabelToolStripMenuItem,
            this.copyGeolocationToolStripMenuItem,
            this.copyIPToolStripMenuItem,
            this.copyPacketsNumberToolStripMenuItem,
            this.copySourceIPToolStripMenuItem,
            this.copySourcePortToolStripMenuItem,
            this.copyDestinationIPToolStripMenuItem,
            this.copyDestinationPortToolStripMenuItem,
            this.copyMACToolStripMenuItem,
            this.copyProtocolToolStripMenuItem,
            this.copyHWDVendorToolStripMenuItem});
            this.logInContextMenu2.Name = "logInContextMenu2";
            this.logInContextMenu2.ShowImageMargin = false;
            this.logInContextMenu2.Size = new System.Drawing.Size(173, 274);
            // 
            // addLabelToolStripMenuItem
            // 
            this.addLabelToolStripMenuItem.Name = "addLabelToolStripMenuItem";
            this.addLabelToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.addLabelToolStripMenuItem.Text = "Add Label";
            this.addLabelToolStripMenuItem.Click += new System.EventHandler(this.addLabelToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(169, 6);
            // 
            // copyLabelToolStripMenuItem
            // 
            this.copyLabelToolStripMenuItem.Name = "copyLabelToolStripMenuItem";
            this.copyLabelToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copyLabelToolStripMenuItem.Text = "Copy Label";
            this.copyLabelToolStripMenuItem.Click += new System.EventHandler(this.copyLabelToolStripMenuItem_Click);
            // 
            // copyGeolocationToolStripMenuItem
            // 
            this.copyGeolocationToolStripMenuItem.Name = "copyGeolocationToolStripMenuItem";
            this.copyGeolocationToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copyGeolocationToolStripMenuItem.Text = "Copy Geolocation";
            this.copyGeolocationToolStripMenuItem.Click += new System.EventHandler(this.copyGeolocationToolStripMenuItem_Click);
            // 
            // copyIPToolStripMenuItem
            // 
            this.copyIPToolStripMenuItem.Name = "copyIPToolStripMenuItem";
            this.copyIPToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copyIPToolStripMenuItem.Text = "Copy External IP";
            this.copyIPToolStripMenuItem.Click += new System.EventHandler(this.copyIPToolStripMenuItem_Click);
            // 
            // copyPacketsNumberToolStripMenuItem
            // 
            this.copyPacketsNumberToolStripMenuItem.Name = "copyPacketsNumberToolStripMenuItem";
            this.copyPacketsNumberToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copyPacketsNumberToolStripMenuItem.Text = "Copy Packets Number";
            this.copyPacketsNumberToolStripMenuItem.Click += new System.EventHandler(this.copyPacketsNumberToolStripMenuItem_Click);
            // 
            // copySourceIPToolStripMenuItem
            // 
            this.copySourceIPToolStripMenuItem.Name = "copySourceIPToolStripMenuItem";
            this.copySourceIPToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copySourceIPToolStripMenuItem.Text = "Copy Source IP";
            this.copySourceIPToolStripMenuItem.Click += new System.EventHandler(this.copySourceIPToolStripMenuItem_Click);
            // 
            // copySourcePortToolStripMenuItem
            // 
            this.copySourcePortToolStripMenuItem.Name = "copySourcePortToolStripMenuItem";
            this.copySourcePortToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copySourcePortToolStripMenuItem.Text = "Copy Source Port";
            this.copySourcePortToolStripMenuItem.Click += new System.EventHandler(this.copySourcePortToolStripMenuItem_Click);
            // 
            // copyDestinationIPToolStripMenuItem
            // 
            this.copyDestinationIPToolStripMenuItem.Name = "copyDestinationIPToolStripMenuItem";
            this.copyDestinationIPToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copyDestinationIPToolStripMenuItem.Text = "Copy Destination IP";
            this.copyDestinationIPToolStripMenuItem.Click += new System.EventHandler(this.copyDestinationIPToolStripMenuItem_Click);
            // 
            // copyDestinationPortToolStripMenuItem
            // 
            this.copyDestinationPortToolStripMenuItem.Name = "copyDestinationPortToolStripMenuItem";
            this.copyDestinationPortToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copyDestinationPortToolStripMenuItem.Text = "Copy Destination Port";
            this.copyDestinationPortToolStripMenuItem.Click += new System.EventHandler(this.copyDestinationPortToolStripMenuItem_Click);
            // 
            // copyMACToolStripMenuItem
            // 
            this.copyMACToolStripMenuItem.Name = "copyMACToolStripMenuItem";
            this.copyMACToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copyMACToolStripMenuItem.Text = "Copy MAC";
            this.copyMACToolStripMenuItem.Click += new System.EventHandler(this.copyMACToolStripMenuItem_Click);
            // 
            // copyProtocolToolStripMenuItem
            // 
            this.copyProtocolToolStripMenuItem.Name = "copyProtocolToolStripMenuItem";
            this.copyProtocolToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copyProtocolToolStripMenuItem.Text = "Copy Protocol";
            this.copyProtocolToolStripMenuItem.Click += new System.EventHandler(this.copyProtocolToolStripMenuItem_Click);
            // 
            // copyHWDVendorToolStripMenuItem
            // 
            this.copyHWDVendorToolStripMenuItem.Name = "copyHWDVendorToolStripMenuItem";
            this.copyHWDVendorToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.copyHWDVendorToolStripMenuItem.Text = "Copy HWD Vendor";
            this.copyHWDVendorToolStripMenuItem.Click += new System.EventHandler(this.copyHWDVendorToolStripMenuItem_Click);
            // 
            // LANMTab
            // 
            this.LANMTab.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.LANMTab.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LANMTab.Controls.Add(this.dataGridView2);
            this.LANMTab.ImageIndex = 0;
            this.LANMTab.Location = new System.Drawing.Point(4, 36);
            this.LANMTab.Name = "LANMTab";
            this.LANMTab.Size = new System.Drawing.Size(805, 250);
            this.LANMTab.TabIndex = 2;
            this.LANMTab.Text = "LAN Machines";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.GridColor = System.Drawing.Color.White;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.ShowEditingIcon = false;
            this.dataGridView2.ShowRowErrors = false;
            this.dataGridView2.Size = new System.Drawing.Size(803, 248);
            this.dataGridView2.TabIndex = 1;
            // 
            // DBTab
            // 
            this.DBTab.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.DBTab.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DBTab.Controls.Add(this.listView1);
            this.DBTab.ImageIndex = 1;
            this.DBTab.Location = new System.Drawing.Point(4, 36);
            this.DBTab.Name = "DBTab";
            this.DBTab.Size = new System.Drawing.Size(805, 250);
            this.DBTab.TabIndex = 3;
            this.DBTab.Text = "Database";
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Label,
            this.IPC});
            this.listView1.ContextMenuStrip = this.logInContextMenu1;
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.ForeColor = System.Drawing.Color.White;
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(0, 0);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(803, 248);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // Label
            // 
            this.Label.Text = "Label";
            this.Label.Width = 390;
            // 
            // IPC
            // 
            this.IPC.Text = "IP";
            this.IPC.Width = 390;
            // 
            // logInContextMenu1
            // 
            this.logInContextMenu1.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInContextMenu1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInContextMenu1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshDBToolStripMenuItem});
            this.logInContextMenu1.Name = "logInContextMenu1";
            this.logInContextMenu1.ShowImageMargin = false;
            this.logInContextMenu1.Size = new System.Drawing.Size(113, 26);
            // 
            // refreshDBToolStripMenuItem
            // 
            this.refreshDBToolStripMenuItem.Name = "refreshDBToolStripMenuItem";
            this.refreshDBToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.refreshDBToolStripMenuItem.Text = "Refresh DB";
            this.refreshDBToolStripMenuItem.Click += new System.EventHandler(this.refreshDBToolStripMenuItem_Click_1);
            // 
            // DebugTab
            // 
            this.DebugTab.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.DebugTab.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DebugTab.Controls.Add(this.textBox7);
            this.DebugTab.ImageIndex = 2;
            this.DebugTab.Location = new System.Drawing.Point(4, 36);
            this.DebugTab.Name = "DebugTab";
            this.DebugTab.Size = new System.Drawing.Size(805, 250);
            this.DebugTab.TabIndex = 4;
            this.DebugTab.Text = "Debug";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox7.ForeColor = System.Drawing.Color.White;
            this.textBox7.Location = new System.Drawing.Point(0, 0);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox7.Size = new System.Drawing.Size(803, 248);
            this.textBox7.TabIndex = 15;
            // 
            // logInThemeContainer1
            // 
            this.logInThemeContainer1.AllowClose = true;
            this.logInThemeContainer1.AllowMaximize = true;
            this.logInThemeContainer1.AllowMinimize = true;
            this.logInThemeContainer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInThemeContainer1.BaseColour = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logInThemeContainer1.BorderColour = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.logInThemeContainer1.CloseChoice = LoginTheme.LogInThemeContainer.@__CloseChoice.Form;
            this.logInThemeContainer1.ContainerColour = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.logInThemeContainer1.Controls.Add(this.logInTabControl1);
            this.logInThemeContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logInThemeContainer1.FontColour = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logInThemeContainer1.FontSize = 12;
            this.logInThemeContainer1.HoverColour = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.logInThemeContainer1.Location = new System.Drawing.Point(0, 0);
            this.logInThemeContainer1.Movable = true;
            this.logInThemeContainer1.Name = "logInThemeContainer1";
            this.logInThemeContainer1.ShowIcon = true;
            this.logInThemeContainer1.Sizable = true;
            this.logInThemeContainer1.Size = new System.Drawing.Size(813, 325);
            this.logInThemeContainer1.SmartBounds = true;
            this.logInThemeContainer1.TabIndex = 1;
            this.logInThemeContainer1.Text = "LANC v2";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(813, 325);
            this.Controls.Add(this.logInThemeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LANC v2";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.logInTabControl1.ResumeLayout(false);
            this.HomeTab.ResumeLayout(false);
            this.HomeTab.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.logInGroupBox2.ResumeLayout(false);
            this.logInGroupBox2.PerformLayout();
            this.logInGroupBox1.ResumeLayout(false);
            this.logInGroupBox1.PerformLayout();
            this.ConnectionsTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.logInContextMenu2.ResumeLayout(false);
            this.LANMTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.DBTab.ResumeLayout(false);
            this.logInContextMenu1.ResumeLayout(false);
            this.DebugTab.ResumeLayout(false);
            this.DebugTab.PerformLayout();
            this.logInThemeContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private LoginTheme.LogInTabControl logInTabControl1;
        private System.Windows.Forms.TabPage HomeTab;
        private System.Windows.Forms.TabPage ConnectionsTab;
        private System.Windows.Forms.TabPage LANMTab;
        private System.Windows.Forms.TabPage DBTab;
        private System.Windows.Forms.TabPage DebugTab;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader Label;
        private System.Windows.Forms.TextBox textBox7;
        private LoginTheme.LogInButton logInButton1;
        private LoginTheme.LogInCheckBox logInCheckBox2;
        private LoginTheme.LogInCheckBox logInCheckBox1;
        private LoginTheme.LogInCheckBox logInCheckBox3;
        private LoginTheme.LogInComboBox logInComboBox1;
        private System.Windows.Forms.Panel panel1;
        private LoginTheme.LogInGroupBox logInGroupBox1;
        private LoginTheme.LogInGroupBox logInGroupBox2;
        private LoginTheme.LogInComboBox logInComboBox3;
        private LoginTheme.LogInLabel logInLabel2;
        private LoginTheme.LogInComboBox logInComboBox2;
        private LoginTheme.LogInLabel logInLabel1;
        private LoginTheme.LogInLabel logInLabel8;
        private LoginTheme.LogInLabel logInLabel9;
        private LoginTheme.LogInNormalTextBox logInNormalTextBox1;
        private LoginTheme.LogInLabel logInLabel3;
        private LoginTheme.LogInNormalTextBox logInNormalTextBox2;
        private LoginTheme.LogInLabel logInLabel4;
        private LoginTheme.LogInNormalTextBox logInNormalTextBox3;
        private LoginTheme.LogInLabel logInLabel5;
        private LoginTheme.LogInNormalTextBox logInNormalTextBox4;
        private LoginTheme.LogInLabel logInLabel6;
        private LoginTheme.LogInContextMenu logInContextMenu1;
        private System.Windows.Forms.ToolStripMenuItem refreshDBToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ColumnHeader IPC;
        private LoginTheme.LogInContextMenu logInContextMenu2;
        private System.Windows.Forms.ToolStripMenuItem addLabelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyIPToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem copyLabelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copySourceIPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copySourcePortToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyDestinationIPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyDestinationPortToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyMACToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyProtocolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyHWDVendorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyGeolocationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyPacketsNumberToolStripMenuItem;
        private LoginTheme.LogInButton logInButton2;
        private LoginTheme.LogInThemeContainer logInThemeContainer1;
    }
}

