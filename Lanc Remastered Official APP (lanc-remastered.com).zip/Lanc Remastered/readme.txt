Support us at www.lanc-remastered.com for latest updates and versions

If you have any errors, install these libraries -

1. Microsoft Visual C++ 2010 
https://www.microsoft.com/en-us/download/confirmation.aspx?id=5555

2. Winpcap
https://www.winpcap.org/install/ 